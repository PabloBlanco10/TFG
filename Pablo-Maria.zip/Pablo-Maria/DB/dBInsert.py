import EXIF2, glob, os#, tempfile, gtk
#import MySQLdb
from StringIO import StringIO
from Exception.exception import GenException
from PIL import Image
from PIL import ImageChops
import math
from datetime import datetime
from PIL import ImageStat

from PRNU.cropImage import *
from PRNU.constants import *

#from Interface.listMsgWindow import Listmsgwindow

from Features import imageFeaturesC
from PRNU.prnu import *
import multiprocessing
from multiprocessing import Lock
import time
from Features import ColorFeat
from Features import WaveFeat
from Features import WaveSmartFeat
from Features import IQMFeat
from Features.SVMClass import SVMClass


from Features.ScanVsCamera_SVM import scanVsCamera


def ColorFeatures(filename, idImage):
    try:
        InsColor_Feat = None
        imf = imageFeaturesC.imageFeatures()
        CF = ColorFeat.ColorFeat()
        if CROP_REQUIRED:
            img = cropImageFilename(filename, CROP_X_SIZE, CROP_Y_SIZE, CROPCENT_REQUIRED)
        else:
            img = Image.open(filename)
        mode = img.mode
        if (mode == "1" or mode == "L" or mode == "P" or mode == "I" or mode == "F" or  ##one band
                    mode == "RGB" or mode == "YCbCr" or  ##three bands
                    mode == "RGBA" or mode == "CMYK"):  ##four bands
            CF = imf.Color_Features(img)
            InsColor_Feat = "insert into Color_Features(IdImage,"
            valColor_Feat = ""#idImage + "',"
            #InsColor_Feat,
            valColor_Feat = genInsFeature(InsColor_Feat, valColor_Feat, "avgPixVal",
                                                              CF.averagePixelValue)
            #InsColor_Feat,
            valColor_Feat = genInsFeature(InsColor_Feat, valColor_Feat, "rgbPairsCor",
                                                              CF.rgbPairsCorrelation)
            #InsColor_Feat,
            valColor_Feat = genInsFeature(InsColor_Feat, valColor_Feat, "DistCentMass",
                                                              CF.rgbPairsEnergyRatio)
            #InsColor_Feat,
            valColor_Feat = genInsFeature(InsColor_Feat, valColor_Feat, "rgbEnergyRat",
                                                              CF.rgbPairsEnergyRatio)
            #InsColor_Feat = InsColor_Feat[:len(InsColor_Feat) - 1] + ")"
            valColor_Feat = valColor_Feat[:len(valColor_Feat) - 1]## + ")"
            InsColor_Feat = InsColor_Feat + " " + valColor_Feat + ";"

        return valColor_Feat##InsColor_Feat

    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los caos necesarios
        tamArgs = len(e.args)
        if tamArgs == 0:
            errorDB = GenException("No info exception")
        if tamArgs == 1:
            errorDB = GenException("%s" % (e.args[0]))
        if tamArgs == 2:
            errorDB = GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB

def WaveletsFeatures(self, filename,idImage):
    try:
        imf = imageFeaturesC.imageFeatures()
        img = Image.open(filename)
        InsWave_Feat = None
        mode=img.mode
        if(mode == "1" or mode == "L"  or mode == "P" or mode == "I"  or mode == "F" or ##one band
           mode == "RGB" or mode == "YCbCr" or ##three bands
           mode == "RGBA" or mode == "CMYK"): ##four bands
            WF = WaveFeat.WaveFeat()
            WF = imf.Wavelets_Features(img)
            InsWave_Feat = "insert into Wavelet_Features(IdImage,rH, rV, rD, gH, gV, gD, bH, bV, bD)"
            valWave_Feat = "values('" + idImage + "',%s,%s,%s,%s,%s,%s,%s,%s,%s)"% (round(WF.rH,20), round(WF.rV,20), round(WF.rD,20),round(WF.gH,20), round(WF.gV,20), round(WF.gD,20),round(WF.bH,20), round(WF.bV,20), round(WF.bD,20))
            InsWave_Feat = InsWave_Feat + " " + valWave_Feat + ";"
        return InsWave_Feat
    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los caos necesarios
        tamArgs=len(e.args)
        if tamArgs==0:
            errorDB= GenException("No info exception")
        if tamArgs==1:
            errorDB= GenException("%s" % (e.args[0]))
        if tamArgs==2:
            errorDB= GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB

def WaveletsSmartFeatures(filename, idImage):
    try:
        imf = imageFeaturesC.imageFeatures()
        if CROP_REQUIRED:
            img = cropImageFilename(filename, CROP_X_SIZE, CROP_Y_SIZE, CROPCENT_REQUIRED)
        else:
            img = Image.open(filename)
        mode=img.mode
        InsWave_Feat = None
        if(mode == "1" or mode == "L"  or mode == "P" or mode == "I"  or mode == "F" or ##one band
           mode == "RGB" or mode == "YCbCr" or ##three bands
           mode == "RGBA" or mode == "CMYK"): ##four bands

            WF = WaveSmartFeat.WaveSmartFeat()
            #imageArray=image2array(img)
            WF = imf.WaveletsSmart_Features(image2array(img))
            InsWave_Feat = "insert into WaveletSmart_Features(IdImage,B1HM1, B1HM2, B1HM3," \
                           "B1HM4, B1HM5, B1HM6, B1HM7, B1HM8, B1HM9, " \
                           "B1HV1, B1HV2, B1HV3, B1HV4, B1HV5, B1HV6, B1HV7, B1HV8, B1HV9," \
                           "B1HD1, B1HD2, B1HD3, B1HD4, B1HD5, B1HD6, B1HD7, B1HD8, B1HD9," \
                           "B2HM1, B2HM2, B2HM3, B2HM4, B2HM5, B2HM6, B2HM7, B2HM8, B2HM9," \
                           "B2HV1, B2HV2, B2HV3, B2HV4, B2HV5, B2HV6, B2HV7, B2HV8, B2HV9," \
                           "B2HD1, B2HD2, B2HD3, B2HD4, B2HD5, B2HD6, B2HD7, B2HD8, B2HD9," \
                           "B3HM1, B3HM2, B3HM3, B3HM4, B3HM5, B3HM6, B3HM7, B3HM8, B3HM9," \
                           "B3HV1, B3HV2, B3HV3, B3HV4, B3HV5, B3HV6, B3HV7, B3HV8, B3HV9," \
                           "B3HD1, B3HD2, B3HD3, B3HD4, B3HD5, B3HD6, B3HD7, B3HD8, B3HD9," \
                           "B4HM1, B4HM2, B4HM3, B4HM4, B4HM5, B4HM6, B4HM7, B4HM8, B4HM9," \
                           "B4HV1, B4HV2, B4HV3, B4HV4, B4HV5, B4HV6, B4HV7, B4HV8, B4HV9," \
                           "B4HD1, B4HD2, B4HD3, B4HD4, B4HD5, B4HD6, B4HD7, B4HD8, B4HD9)"
            valWave_Feat =  "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" \
                            ",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" \
                            ",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" \
                            ",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" \
                            ",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s" \
                            ",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s"% (round(WF.B1HM1,20), round(WF.B1HM2,20), round(WF.B1HM3,20),
                             round(WF.B1HM4,20), round(WF.B1HM5,20), round(WF.B1HM6,20),
                             round(WF.B1HM7,20), round(WF.B1HM8,20), round(WF.B1HM9,20),
                             round(WF.B1HV1,20), round(WF.B1HV2,20), round(WF.B1HV3,20),
                             round(WF.B1HV4,20), round(WF.B1HV5,20), round(WF.B1HV6,20),
                             round(WF.B1HV7,20), round(WF.B1HV8,20), round(WF.B1HV9,20),
                             round(WF.B1HD1,20), round(WF.B1HD2,20), round(WF.B1HD3,20),
                             round(WF.B1HD4,20), round(WF.B1HD5,20), round(WF.B1HD6,20),
                             round(WF.B1HD7,20), round(WF.B1HD8,20), round(WF.B1HD9,20),
                             round(WF.B2HM1,20), round(WF.B2HM2,20), round(WF.B2HM3,20),
                             round(WF.B2HM4,20), round(WF.B2HM5,20), round(WF.B2HM6,20),
                             round(WF.B2HM7,20), round(WF.B2HM8,20), round(WF.B2HM9,20),
                             round(WF.B2HV1,20), round(WF.B2HV2,20), round(WF.B2HV3,20),
                             round(WF.B2HV4,20), round(WF.B2HV5,20), round(WF.B2HV6,20),
                             round(WF.B2HV7,20), round(WF.B2HV8,20), round(WF.B2HV9,20),
                             round(WF.B2HD1,20), round(WF.B2HD2,20), round(WF.B2HD3,20),
                             round(WF.B2HD4,20), round(WF.B2HD5,20), round(WF.B2HD6,20),
                             round(WF.B2HD7,20), round(WF.B2HD8,20), round(WF.B2HD9,20),
                             round(WF.B3HM1,20), round(WF.B3HM2,20), round(WF.B3HM3,20),
                             round(WF.B3HM4,20), round(WF.B3HM5,20), round(WF.B3HM6,20),
                             round(WF.B3HM7,20), round(WF.B3HM8,20), round(WF.B3HM9,20),
                             round(WF.B3HV1,20), round(WF.B3HV2,20), round(WF.B3HV3,20),
                             round(WF.B3HV4,20), round(WF.B3HV5,20), round(WF.B3HV6,20),
                             round(WF.B3HV7,20), round(WF.B3HV8,20), round(WF.B3HV9,20),
                             round(WF.B3HD1,20), round(WF.B3HD2,20), round(WF.B3HD3,20),
                             round(WF.B3HD4,20), round(WF.B3HD5,20), round(WF.B3HD6,20),
                             round(WF.B3HD7,20), round(WF.B3HD8,20), round(WF.B3HD9,20),
                             round(WF.B4HM1,20), round(WF.B4HM2,20), round(WF.B4HM3,20),
                             round(WF.B4HM4,20), round(WF.B4HM5,20), round(WF.B4HM6,20),
                             round(WF.B4HM7,20), round(WF.B4HM8,20), round(WF.B4HM9,20),
                             round(WF.B4HV1,20), round(WF.B4HV2,20), round(WF.B4HV3,20),
                             round(WF.B4HV4,20), round(WF.B4HV5,20), round(WF.B4HV6,20),
                             round(WF.B4HV7,20), round(WF.B4HV8,20), round(WF.B4HV9,20),
                             round(WF.B4HD1,20), round(WF.B4HD2,20), round(WF.B4HD3,20),
                             round(WF.B4HD4,20), round(WF.B4HD5,20), round(WF.B4HD6,20),
                             round(WF.B4HD7,20), round(WF.B4HD8,20), round(WF.B4HD9,20))
            InsWave_Feat = InsWave_Feat + " " + valWave_Feat + ";"

        return valWave_Feat##InsWave_Feat
    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los casos necesarios
        tamArgs=len(e.args)
        if tamArgs==0:
            errorDB= GenException("No info exception")
        if tamArgs==1:
            errorDB= GenException("%s" % (e.args[0]))
        if tamArgs==2:
            errorDB= GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB

def IQMFeatures(filename,idImage):
    try:

        imf = imageFeaturesC.imageFeatures()
        IQMF = IQMFeat.IQMFeat()
        if CROP_REQUIRED:
            img = cropImageFilename(filename, CROP_X_SIZE, CROP_Y_SIZE, CROPCENT_REQUIRED)
        else:
            img = Image.open(filename)
        InsIQM_Feat = None
        mode=img.mode
        if(mode == "1" or mode == "L"  or mode == "P" or mode == "I"  or mode == "F" or ##one band
           mode == "RGB" or mode == "YCbCr" or ##three bands
           mode == "RGBA" or mode == "CMYK"): ##four bands
            IQMF = imf.IQM_Features(img)
            InsIQM_Feat = "insert into IQM_Features(IdImage,"
            valIQM_Feat = ""#idImage + "',"
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "minkowsky1", IQMF.minkowsky1)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "minkowsky2",IQMF.minkowsky2)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "normCrossCor", IQMF.normCrossCor)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "structCont", IQMF.structCont)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "hvsNormAbseErr", IQMF.hvsNormAbseErr)
            #InsIQM_Feat,
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "hvsBasedL2",IQMF.hvsBasedL2)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "laplacianMSE", IQMF.laplacianMSE)
            #InsIQM_Feat += "czekonowskyDist,"
            valIQM_Feat += "%s," % (round(IQMF.czekonowskyDist,20))
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "spectralPhase", IQMF.spectralPhase)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "spectralMagnit", IQMF.spectralMagnit)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "wSpectralDist",IQMF.wSpectralDist)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "medianBlockSpecMag", IQMF.medianBlockSpecMag)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "medianBlockSpecPh", IQMF.medianBlockSpecPh)
            #InsIQM_Feat, \
            valIQM_Feat= genInsFeature(InsIQM_Feat, valIQM_Feat, "medianBlockWSpecDist", IQMF.medianBlockWSpecDist)
            #InsIQM_Feat = InsIQM_Feat[:len(InsIQM_Feat) - 1] + ")"
            valIQM_Feat = valIQM_Feat[:len(valIQM_Feat) - 1]# + ")"
            #InsIQM_Feat = InsIQM_Feat + " " + valIQM_Feat + ";"
        return valIQM_Feat##InsIQM_Feat

    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los caos necesarios
        tamArgs=len(e.args)
        if tamArgs==0:
            errorDB= GenException("No info exception")
        if tamArgs==1:
            errorDB= GenException("%s" % (e.args[0]))
        if tamArgs==2:
            errorDB= GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB

def NoiseFeatures(filename,idImage):
    try:

        if CROP_REQUIRED:
            img = cropImageFilename(filename, CROP_X_SIZE, CROP_Y_SIZE, CROPCENT_REQUIRED)
        else:
            img = Image.open(filename)
        InsNoise_Feat = None
        mode=img.mode
        if(mode == "1" or mode == "L"  or mode == "P" or mode == "I"  or mode == "F" or ##one band
           mode == "RGB" or mode == "YCbCr" or ##three bands
           mode == "RGBA" or mode == "CMYK"): ##four bands
            classSvsC = scanVsCamera(img)

            #print classSvsC.getCaracteristicasPrimerOrden()
            #print classSvsC.getCaracteristicasAltoOrden()
            #print classSvsC.getCaracteristicaRuidoMedio()
            #print classSvsC.getTodasCaracteristicas()

            InsNoise_Feat = "insert into noise_features(IdImage,"
            valNoise_Feat = "values('" + idImage + "',"

            InsNoise_Feat += "mediaCol,mediaRow,medianaCol,medianaRow,maxCol,maxRow,minCol,minRow,"\
                           "varianzaRow,varianzaCol,kurtosisCol,kurtosisRow,skewnessCol,skewnessRow,ratio,mediaNoise,"
            valNoise_Feat += "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"\
                %(round(classSvsC.mediaCol,20),round(classSvsC.mediaRow,20),round(classSvsC.medianaCol,20),
                  round(classSvsC.medianaRow,20),round(classSvsC.maxCol,20),round(classSvsC.maxRow,20),
                  round(classSvsC.minCol,20),round(classSvsC.minRow,20),round(classSvsC.varianzaCol,20),
                  round(classSvsC.varianzaRow,20),round(classSvsC.kurtosisCol,20),round(classSvsC.kurtosisRow,20),
                  round(classSvsC.skewnessCol,20),round(classSvsC.skewnessRow,20),round(classSvsC.ratio,20),
                  round(classSvsC.mediaNoise,20))

            InsNoise_Feat = InsNoise_Feat[:len(InsNoise_Feat) - 1] + ")"
            valNoise_Feat = valNoise_Feat[:len(valNoise_Feat) - 1] + ")"
            InsNoise_Feat = InsNoise_Feat + " " + valNoise_Feat + ";"

        return InsNoise_Feat

    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los caos necesarios
        tamArgs=len(e.args)
        if tamArgs==0:
            errorDB= GenException("No info exception")
        if tamArgs==1:
            errorDB= GenException("%s" % (e.args[0]))
        if tamArgs==2:
            errorDB= GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB

def extractFeatures(q,lock,IdProject,idProc,pathFile, FeatureExtract, outFile, classSVM):
    idAuxImage = 0
    if(q.empty()):
        salir = True
    else:
        salir = False
    while(not salir):
        filename = q.get()
        id = idAuxImage##getIdImage(IdProject)
        fileBin = open(pathFile+"/" +filename, 'rb',1)#leer archivo para sacar

#        fileBinData = MySQLdb.Binary(fileBin.read())
        fileBin.seek(0)
        tags,errors = EXIF2.process_file(fileBin,detecErr=False)#,debug=True)#,details=True)#
        print tags
        #lock
        #print "findTag" +str(idProc)
        IdImage = str(IdProject)+'-'+str(id)+'-'+str(idProc)
        #print "idIma"+IdImage
        ##InsMain_info, InsImage_info, InsExif_info, InsGPS_info, InsInter_info, InsTHUMBNAIL_info, swMakerNote, binMaker, swBLOB,  binThumb, InsJPEGThumbnail_info, valJPEGThumbnail_info = self.findTags(tags,errors,IdImage,filename,pathFile,IdProject)
        ##InsDiff, sqlUPjpgThum_info, fileBinTM = self.createThumbnail(IdImage, pathFile, filename, binThumb, swBLOB,fileBinData)

        if (FeatureExtract=='Y'):
            InsColor_Feat = ColorFeatures(pathFile+"/" +filename, IdImage)
            InsColor_Feat = str(InsColor_Feat).split(",")
            #print InsColor_Feat
            ##InsWave_Feat =self.WaveletsFeatures(filename, IdImage) ##Old Wavelets
            InsWave_Feat = WaveletsSmartFeatures(pathFile+"/" +filename, IdImage)
            InsWave_Feat = str(InsWave_Feat).split(",")
            #print InsWave_Feat
            InsIQM_Feat = IQMFeatures(pathFile+"/" +filename, IdImage)
            InsIQM_Feat = str(InsIQM_Feat).split(",")
            #print InsIQM_Feat
            #return InsColor_Feat, InsWave_Feat, InsIQM_Feat
            #InsNoise_Feat = NoiseFeatures(filename, IdImage)
            #print "InsNoise_Feat " + InsNoise_Feat
        else:
            InsColor_Feat=None
            InsWave_Feat=None
            InsIQM_Feat=None
            InsNoise_Feat=None

        lock.acquire()
        createClassFile(InsColor_Feat + InsWave_Feat + InsIQM_Feat,outFile,classSVM)
        #swInsert = self.insertTags(IdImage, filename, pathFile, fileBinData, InsMain_info, InsImage_info, InsExif_info, InsGPS_info, InsInter_info, InsTHUMBNAIL_info, swMakerNote, binMaker, swBLOB,  binThumb, InsJPEGThumbnail_info, valJPEGThumbnail_info, InsDiff, sqlUPjpgThum_info, fileBinTM, InsColor_Feat, InsWave_Feat, InsIQM_Feat, InsNoise_Feat, errors)
        fileBin.close()
        lock.release()

        if(q.empty()):
            salir = True
        idAuxImage += 1

def isImage(pathFile, filename):
    """
    \brief Method that Opens and identifies the given image file.
    \param self (dBInsert::DBInsert).
    \param pathFile (string) Path of file.
    \param filename (string) Filename of image to open.
    \return swisImg (bool) swisImg = True when file is a image, swisImg = False when file isn't a image.
    \exception when file isn't a image will be insert a new item in the list (lstError) with information that indicate the error.
    """
    try:
        filename=os.path.join(pathFile, filename)
        swisImg = False
        i=Image.open(filename)
        swisImg = True
    except IOError, e:
        strError = "Filename: %s, Path: %s %s" % (filename, pathFile, e)
        print strError
        #self.db.lstError.insert(len(self.db.lstError),"%s" % (strError))
    return swisImg

def genInsFeature(InsSQLFeat, valSQLFeat, nameFeat, valFeat):
    try:
            InsSQLFeat += nameFeat+"R," + nameFeat+"G," + nameFeat+"B,"
            valSQLFeat += "%s,%s,%s,"% (round(valFeat[0],20), round(valFeat[1],20), round(valFeat[2],20))
            #valSQLFeat += round(valFeat[0],20) + "," + round(valFeat[1],20) + "," + round(valFeat[2],20)
            return valSQLFeat##InsSQLFeat, valSQLFeat
    except GenException, e:
        raise e
    except MySQLdb.Error, e:
        ##aqui va el roolback en los caos necesarios
        tamArgs=len(e.args)
        if tamArgs==0:
            errorDB= GenException("No info exception")
        if tamArgs==1:
            errorDB= GenException("%s" % (e.args[0]))
        if tamArgs==2:
            errorDB= GenException("%s: %s" % (e.args[0], e.args[1]))
        raise errorDB
#-- DBInsert.insertPhotos



def insertPhotosParalel(lstFiles, IdProject, pathFile, outFile, classSVM, FeatureExtract='N'):
    """
    \brief Method that to open file that have data to insert in database.
    \brief In this method it called a insertTags Method for to insert new image in Database.
    \param self (dBInsert::DBInsert).
    \param lstFiles (list) list files to insert.
    \param IdProject (int) Project identification.
    \param pathFile (string) Path of file.
    \return No return.
    """
    try:
        start = time.time()
        #"Insertar fotos"
        #####multiproceso
        q = multiprocessing.Queue()
        ## q es una cola donde se mete la lista de archivos
        for i in range(len(lstFiles)):
            swInsert=False
            name_file=lstFiles[i]
            swInsert=isImage(pathFile, name_file)
            if swInsert== True:
                q.put(lstFiles[i])
        procesos = []
        idProc = 0
        lock = Lock()
        while(idProc<multiprocessing.cpu_count() and idProc<len(lstFiles)):
            #print "multiprocessing.cpu_count():%s" % idProc
            #print multiprocessing.cpu_count()
            #print "len(lstFiles): %s" % len(lstFiles)
            p = multiprocessing.Process(target=extractFeatures(q,lock,IdProject,idProc,pathFile,FeatureExtract,outFile,classSVM))
            procesos.append(p)
            p.start()
            idProc=idProc+1

        for idProc in range(len(procesos)):
            procesos[idProc].join()

        print "Tiempo trascurrido: " +  str(time.time()-start)

    except GenException, e:
        raise e
#-- DBInsert.insertPhotos }


def getFiles(nameDir,typeFile):
    """
    #typeFile =['jpeg','jpg','png', 'gif']
    \brief Method that gets list files in a Path.
    \param self (dBInsert::DBInsert).
    \param nameDir (string) Path.
    \param typeFile (string) Type Files to search.
    \return lstFiles (list) list found files in path.
    """
    try:
        os.chdir(nameDir)
        typeFile = "*." + typeFile
        lstFiles = glob.glob(typeFile)
        return lstFiles
    except GenException, e:
        raise e
#-- DBInsert.getFiles }


def createClassFile(listFeatures,outFile,classSVM):
    indice = 0
    f = open(outFile+"imagesFeatures.train", "a")
    f.write(str(classSVM) + " ")
    for features in listFeatures:
        f.write(str(indice)+":"+str(features)+" ")
        indice+=1
    f.write("\n")
    f.close()