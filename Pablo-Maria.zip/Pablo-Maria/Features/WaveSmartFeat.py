class WaveSmartFeat:
    #BXWMY Band X, wavelet component (H, V, D), absolute central moment Y
    #Init to 0 NOT to None because although not all values are used in all the cases. However they are necessary to insert all values in database
    #b1h
    B1HM1= 0
    B1HM2= 0
    B1HM3= 0
    B1HM4= 0
    B1HM5= 0
    B1HM6= 0
    B1HM7= 0
    B1HM8= 0
    B1HM9= 0
    #b1v
    B1HV1= 0
    B1HV2= 0
    B1HV3= 0
    B1HV4= 0
    B1HV5= 0
    B1HV6= 0
    B1HV7= 0
    B1HV8= 0
    B1HV9= 0
    #b1D
    B1HD1= 0
    B1HD2= 0
    B1HD3= 0
    B1HD4= 0
    B1HD5= 0
    B1HD6= 0
    B1HD7= 0
    B1HD8= 0
    B1HD9= 0
    
    #b2h
    B2HM1= 0
    B2HM2= 0
    B2HM3= 0
    B2HM4= 0
    B2HM5= 0
    B2HM6= 0
    B2HM7= 0
    B2HM8= 0
    B2HM9= 0
    #b2v
    B2HV1= 0
    B2HV2= 0
    B2HV3= 0
    B2HV4= 0
    B2HV5= 0
    B2HV6= 0
    B2HV7= 0
    B2HV8= 0
    B2HV9= 0
    #b2D
    B2HD1= 0
    B2HD2= 0
    B2HD3= 0
    B2HD4= 0
    B2HD5= 0
    B2HD6= 0
    B2HD7= 0
    B2HD8= 0
    B2HD9= 0
    
    #b3h
    B3HM1= 0
    B3HM2= 0
    B3HM3= 0
    B3HM4= 0
    B3HM5= 0
    B3HM6= 0
    B3HM7= 0
    B3HM8= 0
    B3HM9= 0
    #b3v
    B3HV1= 0
    B3HV2= 0
    B3HV3= 0
    B3HV4= 0
    B3HV5= 0
    B3HV6= 0
    B3HV7= 0
    B3HV8= 0
    B3HV9= 0
    #b3D
    B3HD1= 0
    B3HD2= 0
    B3HD3= 0
    B3HD4= 0
    B3HD5= 0
    B3HD6= 0
    B3HD7= 0
    B3HD8= 0
    B3HD9= 0
    
    #b4h
    B4HM1= 0
    B4HM2= 0
    B4HM3= 0
    B4HM4= 0
    B4HM5= 0
    B4HM6= 0
    B4HM7= 0
    B4HM8= 0
    B4HM9= 0
    #b4v
    B4HV1= 0
    B4HV2= 0
    B4HV3= 0
    B4HV4= 0
    B4HV5= 0
    B4HV6= 0
    B4HV7= 0
    B4HV8= 0
    B4HV9= 0
    #b4D
    B4HD1= 0
    B4HD2= 0
    B4HD3= 0
    B4HD4= 0
    B4HD5= 0
    B4HD6= 0
    B4HD7= 0
    B4HD8= 0
    B4HD9= 0
    
