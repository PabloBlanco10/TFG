
class IQMFeat:
    minkowsky1 = None
    minkowsky2 = None
    normCrossCor = None
    structCont = None
    hvsNormAbseErr = None
    hvsBasedL2 = None
    laplacianMSE = None
    czekonowskyDist = None
    spectralPhase = None
    spectralMagnit = None
    wSpectralDist = None
    medianBlockSpecMag = None
    medianBlockSpecPh = None
    medianBlockWSpecDist = None
    