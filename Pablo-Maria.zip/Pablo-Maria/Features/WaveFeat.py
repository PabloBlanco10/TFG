
class WaveFeat:
    rH= None
    rV= None
    rD= None
    gH= None
    gV= None
    gD= None
    bH= None
    bV= None
    bD = None