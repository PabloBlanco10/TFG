
class ColorFeat:
    averagePixelValue = None
    rgbPairsCorrelation = None
    neighborDistributionCenterOfMass = None
    rgbPairsEnergyRatio = None