from DB import dBInsert
import os

class Controller:

    #Directorio donde se encuentran las muestras para analizar#
    def __init__(self, dirPath, outPath, fileType):
        """
        \param dirPath (string) Root path of all the pictures (models and brands)
        \param outPath (string) Path where the files of class and features will be create
        \param fileType (string) Type of image format, could be: jpg, jpeg, png, gif...etc.
        """
        self.dirPath = dirPath
        self.outPath = outPath
        self.fileType = fileType


    def createClassFile(self):
        count = 0
        f = open(self.outPath+"classRelation.clre", "w")
        lstProject = []
        for root, subdirs, files in os.walk(self.dirPath):
            if files.__len__()!=0:
                if root.__str__()[self.dirPath.__len__():].__len__() !=0:
                    f.write(count.__str__() +" "+root.split("/")[root.split("/").__len__()-1]+"\n")
                    lstProject.append([count ,root,files])
                    count +=1
                else:
                    f.write(count.__str__() + " " + root.split("/")[0]+"\n")
                    lstProject.append([count, root, files])
                    count += 1
        f.close()
        #for elements in lstProject:
        #    print elements
        self.createFeaturesFile(lstProject)

    def createFeaturesFile(self,lstProject):
        g = open(self.outPath + "imagesFeatures.train", "w")
        g.close()
        for elements in lstProject:
            dBInsert.insertPhotosParalel(elements[2], 1, elements[1], self.outPath, elements[0], "Y")





#Controller("Fotos").createClassFile()


#insertPhotosParalel(lstFiles, IdProject, pathFile, FeatureExtract='N'):
    """
    \brief Method that to open file that have data to insert in database.
    \brief In this method it called a insertTags Method for to insert new image in Database.
    \param self (dBInsert::DBInsert).
    \param lstFiles (list) list files to insert.
    \param IdProject (int) Project identification.
    \param pathFile (string) Path of file.
    \return No return.
    """


Controller("/Users/mariasolana/Documents/23:03:2017/Pablo-Maria/Fotos/","/Users/mariasolana/Documents/23:03:2017/Pablo-Maria/","jpg").createClassFile()
